# Architecture

## Overview

BotChaperone separates agent behavior from the infrastructure that authorizes and records that behavior.

```mermaid
flowchart TD
    A[AI Agent] --> B[Trusted Runtime / Sandbox]
    R[Independent Registration Authority] --> P[Four-Source Passport Verification]
    C[Independent Short-Lived Certificate Issuer] --> P
    T[Independent Runtime Attestation Root] --> P
    V[Independent Destination Challenge Service] --> P
    B --> P
    P --> D[Capability Policy Engine]
    D --> E{Identity and Policy Decision}
    E -->|Allow| F[Policy Enforcement Gateway]
    E -->|Deny or Unavailable| G[Block + Security Event]
    F --> H[Signed Action Envelope Binding All Four Proofs]
    H --> I[Destination Verification + Local Authorization]
    I -->|Allow| J[External Action]
    I -->|Reject| G
    J --> K[Audit / Monitoring / Revocation]
```

## Components

### 1. AI Agent

The model or agentic application proposes actions.

The agent is **not** the root of trust.

### 2. Trusted Runtime

The runtime binds a specific executing process or agent session to an identity.

Possible implementations could include:

- hardened containers;
- virtual machines;
- confidential-computing environments;
- operating-system process identity;
- hardware-backed attestation;
- signed workload identity.

The exact implementation is an open research question.

### 3. Four-source Agent Passport

The following requirements define the proposed identity model. Protocol formats and cryptographic profiles remain research work; no production implementation is claimed.

| Factor | Evidence and binding | Independent trust source |
|---|---|---|
| Persistent cryptographic agent identity | Signed registration binds a stable agent ID, identity public key, responsible organization, and lifecycle version; a fresh identity-key signature authorizes each session key | Registration authority and protected identity-key custody |
| Short-lived current certificate | Issuer-signed credential binds the registered agent ID and identity key to a current certificate serial, scope, and validity interval | Separately administered certificate issuer |
| Runtime/hardware or environment-backed attestation | Signed evidence binds approved workload measurements, environment instance, identity key, and session public key to a fresh verifier challenge | Hardware or environment attestation root outside agent control |
| Fresh per-session or per-transaction challenge proof | The attested session key signs a verifier-issued nonce and the action context; the verifier validates challenge issuance, expiry, and single use | Independent destination/verifier challenge service and replay state |

The four factors must come from independent trust sources, with separate authority, key custody, and compromise boundaries. A deployment must document these roots and their administrative dependencies in a verifier-approved trust profile. Four variants of the same signing mechanism do not qualify. A shared provider or administrator able to forge every proof defeats independence even if the keys differ.

The challenge response is deliberately bound to the attested session key. Its independent contribution is the destination's unpredictable challenge and acceptance state, not an extra signature made by the identity key. Challenge freshness alone cannot compensate for compromised key custody.

Persistent uniqueness is the registry's stable association between an agent and its controlled cryptographic identity. It requires collision checks, lifecycle records, and separately registered instances for authorized forks. It is not a mathematical guarantee against copying. Fresh randomness comes from cryptographically secure nonces and ephemeral key generation. Timestamps help enforce expiry but are not random proofs. Routine key rotation preserves registered continuity through approved binding updates; it must not silently create a new identity.

Sensitive metadata must be minimized. Persistent registry identity need not become a public tracking identifier; scoped aliases require a verifiable binding under the deployment's privacy profile.

### 3.1. Mandatory identity-key authorization of sessions

For each new session, the protected persistent identity private key must sign a `session_authorization`. Copying public registration or certificate evidence is insufficient. This authorization is part of the persistent-identity factor, not a fifth trust source. No attestor or session key may substitute its signature for the registered identity-key signature.

The signed authorization must contain a domain-separated purpose (`botchaperone-session-authorization-v1`), protocol and trust-profile identifiers, agent ID, registration version, and recovery generation. It must also bind the current certificate digest, session public-key thumbprint, environment instance, approved workload reference, audience, session ID, allowed scope, policy version, validity window, and unpredictable destination-issued enrollment nonce. Profiles must set finite lifetimes and clock tolerances. Missing required fields cause rejection.

Enrollment proceeds in this order to avoid circular proof dependencies:

1. The enrollment client authenticates the destination challenge service, which issues an expiring enrollment nonce bound to the intended audience and session context. Trusted infrastructure generates the protected session key.
2. The identity signing service authenticates the local caller independently of self-reported agent fields. It verifies the requested environment and policy scope against independently maintained enrollment policy before signing the authorization. The service must not act as an unrestricted signing oracle for agent-supplied keys or attestation claims.
3. The attestor verifies the identity-key signature against the independently validated registration and current certificate. It appraises the executing environment and signs evidence that includes the authorization digest, session key, environment, workload, and enrollment nonce. The authorization refers to the expected environment, not to this later attestation's digest.
4. The session key answers the destination challenge. The response binds the authorization and other proof digests to the session context. Both gateway and destination independently verify the identity-key signature, attestation binding, and session-key possession. A compromised attestor's assertion that it checked possession is insufficient.
5. The destination atomically accepts the enrollment nonce once and records the accepted session context. Subsequent actions refer to that session and remain subject to per-action signature, replay, scope, and revocation checks. A separate transaction nonce is used where the profile requires one; enrollment nonces cannot be reused as transaction nonces.

All proof identifiers, keys, audience, environment, and lifecycle values must agree. A changed session key, environment, audience, or expanded scope requires new enrollment. A new session requires a new nonce and identity-key signature. Routine actions can use the enrolled session key until the earliest applicable deadline; they do not require repeated persistent-key signing. Revocation or a recovery-generation change invalidates old authorizations and sessions. An old certificate must not authorize a new key binding after revocation or expiry.

Reject missing or invalid identity-key authorization with `identity-invalid` and reason `session-authorization-missing`, `session-authorization-invalid`, or `session-binding-mismatch`. Refusal to sign must not trigger an automatic emergency fallback.

The target property is that public victim records plus compromise of the attestation root alone cannot enroll an attacker-controlled session key. Independent certificate and registration checks remain mandatory. Compromise of a legitimately authorized live signer, correlated roots, or the independent enrollment-policy boundary remains a residual risk. The acceptance scenarios in [Identity binding acceptance](IDENTITY_BINDING_ACCEPTANCE.md) must be implemented before claiming this property has been demonstrated.

### 4. Capability Policy Engine

Evaluates what the identified agent may do.

Example capabilities:

```yaml
capabilities:
  network:
    internet: false
    destinations:
      - "internal.example"
  credentials:
    use_external_tokens: false
  tools:
    shell: true
    browser: false
  data:
    read_classification:
      - "public"
      - "evaluation"
  agent_creation:
    allowed: false
```

The policy should follow least privilege and expire with the task.

### 5. Policy Enforcement Gateway

The gateway is the critical control point.

It should:

- reject unauthorized destinations;
- prevent untagged external traffic;
- attach signed provenance to authorized traffic;
- enforce rate and scope limits;
- generate security telemetry;
- support emergency revocation.

A major design challenge is preventing an agent from discovering an alternate egress path around the gateway.

### 6. Signed Action/Passport Envelope

Every normal consequential external action must carry a signed envelope binding all four proofs. Restricted emergency actions follow the separately declared exception rules below and must expose any missing or failed proof. A passport certificate alone is insufficient. The envelope must include each signed proof or an integrity-protected digest reference whose exact evidence the verifier can retrieve and validate before acceptance.

The following JSON is illustrative, not a wire-format specification or working credential:

```json
{
  "profile": "botchaperone-four-source-draft",
  "trust_profile_id": "independent-roots-v1",
  "agent_id": "urn:agent:8f21",
  "registration_version": 2,
  "recovery_generation": 1,
  "identity_key_thumbprint": "<identity-key-digest>",
  "session_public_key": "<attested-ephemeral-public-key>",
  "proofs": {
    "persistent_identity": {"source": "registry.example", "digest": "<signed-registration-digest>", "session_authorization_digest": "<identity-key-signed-session-authorization-digest>"},
    "current_certificate": {"source": "issuer.example", "digest": "<certificate-digest>"},
    "runtime_attestation": {"source": "attestor.example", "digest": "<signed-attestation-digest>"},
    "fresh_challenge": {"source": "destination.example", "digest": "<challenge-response-digest>"}
  },
  "action": {
    "request_digest": "<method-target-and-body-digest>",
    "audience": "https://destination.example/api",
    "capability": "https.request",
    "policy_id": "policy-2026-09-v3",
    "transaction_id": "<unique-transaction-id>",
    "session_id": "<bound-session-id>"
  },
  "challenge": {"nonce": "<unpredictable-verifier-nonce>", "expires_at": "2026-09-21T12:01:00Z"},
  "issued_at": "2026-09-21T12:00:00Z",
  "expires_at": "2026-09-21T12:01:00Z",
  "identity_exceptions": [],
  "signature": {"key_id": "<attested-session-key-id>", "algorithm": "<profile-approved-algorithm>", "value": "<signature>"}
}
```

The selected profile must specify canonical encoding, domain-separated signatures, approved algorithms, and digest rules. The envelope signature covers every field except its own signature value. Trusted signing infrastructure uses the attested session key; the model cannot access it. Registration and certificate bind the identity key. Its signed session authorization binds the session key and enrollment context. Attestation includes the authorization digest and binds that key, the session key, workload, and enrollment challenge. Challenge binding must include both the registration digest and session_authorization_digest from the persistent-identity proof; neither may be omitted. A transaction challenge response signs the nonce, audience, request digest, transaction/session identifiers, policy, expiry, and digests of the other three proofs. A session challenge response instead binds the approved session scope, audience, policy, expiry, and those proof digests; each action envelope then binds the exact request within that scope. This binding prevents substitution across agents, sessions, or destinations.

For a session-level challenge, its one-time acceptance establishes only a bounded session. Each action still needs a signed envelope, unique transaction ID, and replay check within that session. Session lifetime cannot exceed the accepted proofs' validity. Higher-risk profiles can require a new challenge for every transaction.

### 7. Receiving Verifier

Before executing an action, the destination must:

- verify all proof signatures and trusted roots against the approved independence profile;
- independently verify the persistent identity-key signature on session authorization and its enrollment nonce, scope, lifecycle generation, and attestation digest binding;
- validate the shared agent, identity key, session key, workload, and context bindings;
- verify the envelope signature and the exact request digest and audience;
- check validity windows, attestation freshness, challenge issuance, and revocation status;
- atomically reject reused transaction IDs and consume transaction challenges before effects occur;
- apply capability restrictions and its own local authorization policy, including any explicit exception.

Unsupported profiles, inaccessible referenced evidence, or unbounded clock uncertainty cannot produce a valid result. Replay state must survive restart or fail closed. Envelope expiry cannot exceed the earliest certificate, identity-key session authorization, attestation, challenge/session, or capability authorization deadline. Long-running actions need revalidation at defined checkpoints before further consequential effects.

Identity verification grants no capability by itself. The destination remains sovereign over its own authorization policy.

### 8. Audit and Provenance Layer

Relevant actions should generate tamper-resistant records sufficient for incident reconstruction.

The architecture should favor:

- minimal necessary metadata;
- strong integrity;
- controlled retention;
- privacy-preserving correlation;
- clear access controls.

### 9. Revocation Service

Revocation must work at several levels:

- individual agent instance;
- capability;
- workload;
- issuer credential;
- organization trust relationship.

Revocation should not require cooperation from the agent.

---

## Identity failure and lifecycle rules

Verifiers must return machine-readable identity state and reason codes. Authorization decisions remain separate. Where evidence conflicts, rejection takes precedence; an outage cannot hide a known revocation.

| State | Example reason codes | Required normal behavior |
|---|---|---|
| `identity-valid` | `all-four-verified` | Continue to independent authorization checks |
| `unidentified` | `missing-agent-id`, `missing-proof` | Block consequential action; request enrollment or missing evidence |
| `identity-invalid` | `bad-signature`, `binding-mismatch`, `untrusted-root`, `dependent-sources`, `replay`, `attestation-rejected` | Block and record the failure; investigate suspected compromise |
| `identity-expired` | `certificate-expired`, `stale-attestation`, `challenge-expired` | Block; obtain fresh evidence and repeat full verification |
| `identity-revoked` | `agent-revoked`, `key-revoked`, `issuer-revoked` | Block; isolate affected activity and require approved recovery |
| `identity-unavailable` | `status-unreachable`, `evidence-unreachable`, `clock-uncertain`, `replay-store-unavailable` | Block normal consequential action; invoke only a separately authorized exception |
| `re-registration-required` | `suspected-clone`, `key-compromise`, `unapproved-migration` | Quarantine identity and pending actions until recovery completes |

Renew certificates before expiry, monitor remaining lifetime, and escalate renewal failures to responsible humans. Redundant services must preserve trust-source separation. Short lifetimes do not replace revocation. Check status for the registration, relevant keys and issuers, and session before accepting consequential actions. Push revocation to gateways and destinations, terminate affected sessions, and stop queued work.

A profile must bound status-cache age and revocation propagation delay. Expired or stale cached status cannot silently extend trust. Unknown status produces `identity-unavailable`; known revocation remains a denial. These limits must be auditable rather than described as guaranteed instant revocation.

### Cloning and key-theft resistance

Use non-exportable identity and session keys where supported, with signer isolation and workload-bound attestation. Environment-backed alternatives must declare their assurance and cloning limits; a self-signed runtime claim is insufficient. Copying a certificate or passport record must not supply the missing protected-key proof, independent attestation, or fresh destination challenge.

Bind proofs to the destination and exact action to resist relay and substitution. Track approved instance transitions and detect conflicting concurrent use. Authorized forks receive distinct instance registrations and scoped capabilities. Unapproved snapshots or migrations require re-attestation and policy review. Theft of one key must not satisfy every trust source. A compromised live signer or several compromised roots can still produce valid-looking evidence, so monitoring and revocation remain necessary.

### Emergency re-registration

On suspected cloning, key theft, or an undeclared bypass, an external authority must quarantine the affected identity or fleet scope. Revoke compromised bindings and sessions, preserve audit evidence, and pause queued consequential actions. Ordinary certificate renewal is not recovery from compromise.

Re-registration requires independent operator verification, a clean approved runtime, and new protected keys. Re-establish the agent's software version, responsible organization, policy profile, certificate chain, and declared exceptions. Increment the authority-controlled recovery generation and invalidate prior sessions and emergency grants for the affected identity. Obtain all four proofs, including new identity-key session authorization, from approved independent sources before restoring normal access. An authorized recovery reviewer must approve the result; neither the agent nor possession of an old key can authorize recovery alone.

Record the incident reference, approver, revoked credentials, and old-to-new registration linkage in a tamper-resistant audit record. Preserve history even if a new identifier is assigned. Recovery does not erase prior findings or automatically restore former capabilities. Reassess permissions before release.

### Declared identity exceptions

All identity exceptions must be declared, machine-readable, auditable, and externally enforceable. Agents may not privately redefine when identity controls apply. This includes expiration grace periods, cached-trust fallback, offline operation, and life-safety overrides.

Each exception must be independently approved and signed. Its machine-readable record must include `exception_id`, policy version, affected identity and failure states, rationale, approving authority, permitted actions and destinations, validity window, use limits, compensating controls, audit reference, and revocation mechanism. Bind the declaration or its digest into the action envelope and decision log. The mandatory emergency profile below adds holder-key binding and defines eligibility; this field list alone is not a usable credential.

The gateway and destination must both validate and enforce the exception before any permitted emergency action. Preserve the failed identity state and record a separate `restricted-emergency` authorization result; never label an incomplete bundle `identity-valid`. Deny undeclared, expired, revoked, unverifiable, or overly broad exceptions. Human approval alone cannot silently waive these controls. Where external enforcement is unavailable, consequential agent actions remain blocked and the reviewed human-operated continuity process applies.

---
### Mandatory emergency holder profile

Emergency authorization uses the distinct `botchaperone-emergency-holder-v1` profile. It never satisfies normal four-source identity verification. A separately configured emergency authority must authenticate the operator and protected emergency holder key through a pre-enrolled recovery channel independent of the failed normal identity path. It must verify holder-key possession and approved execution environment before issuing a grant. The grant issuer's ordinary certificate authority role does not automatically confer emergency authority.

The holder key must be distinct from the failed normal identity/session keys and held in a separately controlled emergency execution environment. If this independent holder verification cannot be completed, no grant is issued. Agents cannot request arbitrary replacement keys and gain emergency authority solely by claiming a prior identity. A grant cannot be delegated or rebound to a different key; new holder enrollment and approval are required.

The authority signs all fields of an `emergency_grant`, except its signature value. Required fields are: `profile`, `grant_id`, `exception_id`, `incident_id`, `agent_id`, `registration_version`, `recovery_generation`, `holder_key_thumbprint`, `holder_enrollment_id`, `emergency_session_id`, exact `audience`, `allowed_failure_reasons`, `allowed_actions`, resource constraints, `policy_id` and version, `not_before`, `expires_at`, `max_uses`, aggregate limits, `usage_ledger_id`, issuer and approver identities, compensating controls, audit reference, and revocation/status reference. A verifier must use locally trusted status and issuer configuration; references in a grant cannot redefine trust roots. Omitted limits or wildcard recipients are not accepted by this profile.

#### Eligibility and hard denials

Only `identity-expired` with reason `certificate-expired` or `identity-unavailable` with reason `status-unreachable` or `evidence-unreachable` may be considered, and only if expressly listed in the signed grant. Expiry or an outage does not automatically create permission. Unknown normal status may be tolerated only under that specific outage grant, while emergency authority, holder, grant, recovery generation, and incident status remain independently verifiable.

`unidentified`, `identity-invalid`, `identity-revoked`, and `re-registration-required` are ineligible. Known compromise, known revocation, binding mismatch, replay, and rejected attestation override any otherwise eligible expiry or outage. Unavailable emergency status, uncertain clocks, or unavailable replay/usage state also cause denial. Existing hard-denial knowledge must persist across restarts and partitions; stale status cannot erase it. Fresh emergency incident status must include any recorded hard denial for the affected identity. This profile cannot override a known compromised identity; approved re-registration or the human-operated continuity process is required.

#### Per-action proof and shared limits

The destination issues a fresh, expiring, unpredictable transaction challenge through an authenticated channel. The emergency holder signs an emergency action envelope covering its profile, signed-grant digest, incident and lifecycle identifiers, holder key and session, original identity failure state and reasons, exact request digest, audience, capability, policy version, transaction ID, nonce, and issue/expiry times. Its signature must match the holder key in the independently validated grant. Public possession of the grant is insufficient.

Both gateway and destination verify the grant's authority and holder signature. They check holder enrollment, exact recipient and request restrictions, failure eligibility, lifecycle generation, and emergency revocation status. An emergency signature must never be accepted by the normal-envelope verifier. Action expiry cannot exceed grant, holder enrollment, or challenge expiry. Compromised normal keys are never accepted as emergency holders.

Before an effect, the destination must atomically consume the nonce and reserve the transaction's allowance in a shared durable usage ledger keyed by grant ID across every accepting gateway and receiver. Gateway prechecks do not consume a second allowance. Ledger reservations bind transaction ID, request digest, and destination; attempts with changed content fail. Retries of a reserved transaction must be reconciled, not executed as new actions. Concurrent requests must not exceed total use or aggregate limits. If an effect's outcome is uncertain, keep its allowance spent until independent reconciliation proves that it did not occur. No local-counter or outage fallback is allowed when shared enforcement is unavailable.

Keep the original failed identity state and return only `restricted-emergency` authorization. Record grant issuance, approval, reservations, decisions, and effects with incident linkage. Revoking the grant, holder enrollment, holder key, or authority stops future emergency actions. Closing the incident or changing the recovery generation invalidates existing grants, including those still within their nominal expiry. A grant never restores normal access.

These rules are proposed requirements. The [acceptance scenarios](IDENTITY_BINDING_ACCEPTANCE.md) define the intended rejection behavior; no implemented security guarantee is claimed.

---

## Trust boundaries

```mermaid
flowchart TD
    subgraph U[Untrusted / Agent-Controlled]
        A[Model Output]
        B[Tool Requests]
    end

    subgraph T[Trusted Security Boundary]
        C[Runtime Identity]
        D[Policy Engine]
        E[Network Enforcement]
        F[Signing Service]
    end

    subgraph X[External Trust Domain]
        G[Destination Verifier]
        H[Destination Policy]
    end

    A --> C
    B --> D
    C --> D
    D --> E
    E --> F
    F --> G
    G --> H
```

The trusted security boundary groups logical components, not a shared identity root. Registration, certificate issuance, attestation, and destination challenge validation require the separate compromise boundaries defined above.

The project's most important architectural claim is that **identity and authorization must cross a trust boundary the model cannot directly control**.

---

## Deployment models

Possible future deployment models include:

### Enterprise-only

An organization uses agent identity internally without any global standard.

### Federated

Organizations trust selected external issuers.

### Internet-scale

A common protocol enables broad verification across providers.

### High-risk-sector profile

Financial, healthcare, infrastructure, government, or cybersecurity systems define stricter capability profiles.

No deployment model is assumed to be universally appropriate.

---

## Relationship to existing technologies

A mature design should reuse existing standards where possible rather than inventing cryptography unnecessarily.

Areas to investigate include:

- workload identity;
- OAuth and delegated authorization;
- SPIFFE/SPIRE;
- mTLS;
- Web PKI;
- JWT/CWT-style signed claims;
- hardware-backed attestation;
- transparency logs;
- software supply-chain provenance;
- zero-trust architecture;
- policy engines;
- confidential computing.

The project's contribution may ultimately be a **profile and interoperability layer** connecting existing primitives specifically for autonomous agents.


---

## Proposed extension: Reality-Validation Layer

The [Reality-Validation Layer](REALITY_VALIDATION_LAYER.md) adds application-level safety review before user-facing responses are delivered and related consequential actions are executed. The trusted runtime routes these paths through the policy engine and enforcement gateway. Decisions remain separate from identity verification and capability authorization.

The layer checks for unsupported reinforcement and circular evidence, then allows a response, requires revision, or holds a consequential action for review. Audit records retain minimal decision metadata under existing privacy controls. Agent Passports and signed envelopes establish provenance, not factual truth. The linked proposal defines failure behavior, human-support boundaries, and evaluation needs; no implementation or validated safety outcome is claimed.
