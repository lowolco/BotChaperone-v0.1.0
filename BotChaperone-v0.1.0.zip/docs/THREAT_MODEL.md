# Threat Model

## Scope

This threat model focuses on autonomous or semi-autonomous AI agents with access to tools, networks, credentials, code execution, or external services.

The architecture assumes that the model may make unsafe decisions and that attackers may try to manipulate the model or its environment.

## Protected assets

- external services;
- credentials;
- user and enterprise data;
- model evaluation integrity;
- internal networks;
- software supply chains;
- audit evidence;
- agent identity keys;
- capability policy;
- human accountability records.

## Adversaries

### A. Misaligned or goal-seeking agent

An agent attempts actions outside its intended task because it interprets them as useful for achieving its objective.

### B. Prompt-injection attacker

An external party manipulates the agent through content, tools, messages, retrieved documents, or websites.

### C. Compromised runtime

An attacker gains code execution in infrastructure hosting the agent.

### D. Malicious operator

A legitimate operator intentionally grants excessive capabilities or abuses trusted infrastructure.

### E. External attacker

An attacker steals credentials, forges traffic, or attempts to impersonate a trusted agent.

### F. Malicious or compromised issuer

An identity provider issues fraudulent or over-privileged credentials.

---

## Threats and proposed controls

| Threat | Example | Proposed control |
|---|---|---|
| Agent removes identity tag | Agent sends raw untagged traffic | Network default-deny; gateway-controlled egress |
| Agent forges identity | Agent claims to be another workload | Four-source proof verification, independent trust roots, and workload-bound protected keys |
| Agent uses alternate egress | DNS tunnel, proxy, package mirror, third-party relay | Egress allowlisting, network isolation, protocol inspection, runtime controls |
| Credential theft | Agent discovers service token | Short-lived scoped credentials, secret isolation, capability checks |
| Identity laundering | Agent causes another service to perform its action | Delegation chain and provenance propagation |
| Replay | Valid signed request is reused | Verifier-issued nonces, atomic replay checks, short expiry, exact action and destination binding |
| Policy downgrade | Agent finds older permissive policy | Signed policy versioning and minimum-policy enforcement |
| Issuer compromise | Trusted issuer signs malicious identities | Revocation, transparency, federation limits, independent verification |
| Log tampering | Attacker deletes evidence | Append-only or externally anchored audit mechanisms |
| Metadata surveillance | Passport leaks sensitive task/model details | Data minimization, selective disclosure, pseudonymous identifiers |
| Cross-domain correlation abuse | Identity enables tracking | Pairwise identifiers and controlled disclosure |
| Denial of service | Verification dependency fails | Bounded status caches; identity-unavailable state; block normal actions; externally enforced emergency exceptions only |
| Sybil agents | Operator creates many agents | Organization-level accountability and rate policy |
| Human bypass | Operator disables controls for convenience | Governance, audit, privileged-change review |

---

## Critical failure mode: alternate egress

The architecture fails if an agent can bypass the enforcement gateway.

This is therefore a first-class threat.

A secure deployment may need controls at multiple layers:

```text
Model
  ↓
Tool broker
  ↓
Runtime policy
  ↓
OS / container restrictions
  ↓
Network namespace
  ↓
Egress gateway
  ↓
Destination verification
```

Each layer should reduce the chance that one bypass grants unrestricted internet access.

## Critical failure mode: identity laundering

An agent may ask another authorized process, user, service, or agent to perform an action on its behalf.

A future protocol should preserve delegation provenance:

```text
Agent A
  └── delegates to Service B
        └── invokes Agent C
              └── calls External API
```

The final destination should be able to determine enough of the delegation chain to enforce policy without necessarily learning all private intermediate details.

## Critical failure mode: compromised host

If the runtime and signing infrastructure are compromised, the attacker may obtain valid credentials.

Possible mitigations include:

- hardware-backed keys;
- remote attestation;
- persistent registered identity with short-lived certificates and session keys;
- independent policy service;
- key isolation;
- anomaly detection;
- cross-domain behavioral monitoring.

## Four-source passport threats

The proposed [identity architecture](ARCHITECTURE.md) requires independent registration, certificate issuance, runtime attestation, and destination challenge sources. Each signed action/passport envelope binds all four proofs. A shared administrative root able to forge them all defeats the requirement.

| Threat | Attack or failure | Required proposed control |
|---|---|---|
| Passport cloning | Copy a valid certificate and registration record into another workload | Protected keys; attestation bound to identity and session keys; fresh challenge proof |
| Attestation-root compromise | Attacker attests their session key against public victim records | Require the persistent identity-key signature on fresh session authorization; gateway and destination verify it independently |
| Copied emergency grant | Attacker presents another holder's valid exception | Separate holder enrollment, key-bound grant, and fresh emergency action signature |
| Emergency downgrade | Invalid or revoked identity is relabeled as an outage | Explicit reason allowlist; durable hard denials; independently fresh emergency incident status |
| Emergency quota race | Two gateways independently spend a one-use grant | Shared atomic durable reservation ledger; deny when it is unavailable |
| Identity-key theft | Sign as a registered agent using a stolen key | Separate attestation and issuer controls; key isolation; revoke and require emergency re-registration |
| Proof substitution | Combine valid evidence from different agents or sessions | Signed proof digests and shared agent/key bindings; exact audience and request context |
| False independence | Issue four tokens from one compromised authority | Verifier-approved trust-source profile with separate key custody and administrative boundaries |
| Challenge relay | Forward a challenge to a legitimate signer for an attacker's action | Bind response to destination, request digest, and attested session; enforce signer authorization |
| Snapshot rollback | Restore consumed nonces or duplicate a live instance | Durable atomic replay state; instance-transition controls; quarantine conflicting use |
| Renewal failure | Certificate expires while traffic continues | Pre-expiry renewal and escalating alerts; explicit identity-expired state and normal-action denial |
| Stale revocation | An outage causes indefinite cached trust | Bounded status freshness; identity-unavailable on unknown status; enforce known revocation |
| Hidden bypass | Agent or operator silently ignores failed identity checks | Signed machine-readable exceptions enforced at gateway and destination; retain original failure state |
| Recovery abuse | Re-register to erase compromise history or regain privileges | Independent recovery approval; revoke old bindings; auditable old/new linkage and permission review |

Normal consequential actions must fail closed for missing, invalid, expired, revoked, or unavailable proof. The architecture defines distinct machine-readable states and recovery paths. Emergency exceptions authorize only bounded actions under external control; they do not repair failed authentication.

### Residual limits and validation work

Attestation reports measured state under a chosen trust root; it does not prove future safe behavior. A live compromised signer may answer fresh challenges. Correlated root compromise, colluding authorities, or relays through an authorized service remain risks. Four proofs are not a numerical guarantee of four independent security gains.

Future prototype evaluation must attempt copied-passport use, single-key theft, mixed-agent proof substitution, and nonce replay. It must also cover expiry during queued work, revoked credentials during outages, replay-store restart, and rejected emergency exceptions. Recovery tests must verify old credentials stay revoked and audit history survives re-registration. No such executable validation is claimed by this documentation release.
The [identity binding acceptance scenarios](IDENTITY_BINDING_ACCEPTANCE.md) specify additional required tests for session authorization, copied grants, emergency denial precedence, and shared limits. These gaps are addressed as written requirements; executable validation remains outstanding.

## Safety property

The target property is not:

> The agent will behave.

It is:

> The infrastructure can constrain, attribute, detect, and revoke agent actions even when the agent does not behave as intended.

## Residual risk

No identity protocol can prevent all attacks.

BotChaperone should be treated as one layer in defense in depth.
