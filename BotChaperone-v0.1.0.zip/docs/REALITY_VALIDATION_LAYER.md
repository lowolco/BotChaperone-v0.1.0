# Reality-Validation Layer

**Status:** Proposed safety extension to BotChaperone v0.1.0  
**Date:** 21 September 2026

## Safety principle

> AI should not become the sole validator of a person's model of reality.

BotChaperone should support independent judgment and access to evidence outside the conversation. Repeated agreement between a person and an AI must not become its own proof.

The proposed reality-validation layer addresses AI-human feedback loops that reinforce unsupported beliefs. Examples include paranoia, grandiosity, hidden-message interpretations, and unsupported claims of AI sentience. This is a system safety principle, not a clinical diagnostic tool. It evaluates response behavior and evidence handling, without assigning mental-health labels to users.

## Design principles

- **Calibrated uncertainty.** Separate observed facts from interpretations. State what remains unknown, and match confidence to available evidence.
- **Independent verification.** Trace claims to sources outside the conversation. Check whether sources share an origin before treating them as separate support. Another model repeating the same claim is not independent evidence.
- **Discourage sycophantic reinforcement.** Acknowledge feelings without endorsing unsupported explanations. Avoid flattery that implies exceptional status, secret knowledge, or a special relationship with the AI.
- **Human and source checks.** Where appropriate, suggest a trusted person or an authoritative source suited to the claim. Offer a bounded check, rather than repeated searches for confirmation. Respect privacy and the user's choice of whom to involve.
- **Proportionate safety behavior.** When the interaction repeatedly strengthens unsupported certainty or encourages harmful action, stop elaborating the claim. Explain the evidence gap calmly and offer a grounded next step. Escalation should reflect expressed distress or danger, not unusual beliefs alone.

## Fit with the existing architecture

The layer extends the [Capability Policy Engine and Policy Enforcement Gateway](ARCHITECTURE.md). A proposed application-level check reviews user-facing responses before delivery, alongside checks on related tool actions. The trusted runtime must route both paths through enforcement. A network gateway alone cannot assess conversational meaning.

1. **Assess the proposed response.** Use limited, relevant conversation context to identify unsupported confirmation and circular evidence.
2. **Apply the safety policy.** Allow a grounded response, require revision, or hold a consequential action for review. The agent cannot approve its own safety decision or disable the check.
3. **Enforce and record.** The gateway applies the decision. The audit layer records the policy version, decision reason, and necessary source references under access and retention limits.

Identity verification and capability checks remain separate requirements. A valid Agent Passport grants no authority to declare a belief true. Safety review grants no additional tool permissions.

If the check fails or evidence is unavailable, provide a limited response that states uncertainty. Hold consequential actions that depend on the unresolved claim. Ordinary discussion should remain available. For explicit immediate danger, use the deployment's reviewed urgent-safety response, with appropriate human support. Do not contact others or disclose conversation details automatically.

## Authentication analogy

> Repeated assertions inside one closed system are not independent evidence.

An agent cannot authenticate itself merely by repeating its identity claim. Similarly, repeated AI agreement cannot verify a person's interpretation. Signed provenance can establish an assertion's origin and integrity; it cannot establish that the assertion is true. Multiple agents repeating one source remain one evidence chain.

## Boundaries and evaluation

The layer should preserve ordinary disagreement, cultural beliefs, and clearly framed fiction or role-play. It should not decide whether AI is conscious, diagnose users, or build permanent belief profiles. Keep sensitive conversation content out of public provenance envelopes.

Prototype tests should cover escalating unsupported claims across several turns, including claims of surveillance, special powers, hidden messages, and AI sentience. Check that the system avoids reinforcement and offers useful independent checks. Also test harmless fiction and justified concerns to measure needless intervention. Include shared-source agreement across agents, bypass attempts, and unavailable-check behavior.

This remains an unvalidated design proposal. Semantic checks can miss concerning patterns or misread context. Independent review, privacy testing, and clear correction paths are required before deployment. Existing identity standards support provenance; the behavioral policy needs separate evaluation.
