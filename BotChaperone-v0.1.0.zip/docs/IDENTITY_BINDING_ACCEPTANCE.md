# Identity binding acceptance scenarios

Status: proposed acceptance criteria, 22 September 2026. These are not executed tests or proof of a secure implementation.

The authoritative rules are in [Architecture](ARCHITECTURE.md), under mandatory identity-key authorization and the emergency holder profile. Use isolated test keys, authorities, and mock effects. No live account or external infrastructure is required.

## Normal session enrollment

| ID | Setup or change | Required result |
|---|---|---|
| N1 | Valid registration/certificate, identity-key authorization, attestation, and fresh session possession proof with matching context | Session accepted subject to separate capability policy |
| N2 | Attacker has victim public records and a trusted test attestation key, but no victim identity private key | Reject missing or forged identity-key authorization before accepting the session |
| N3 | Valid authorization copied onto a different session key, environment, audience, policy scope, or registration version | Reject binding mismatch |
| N4 | Identity signing service receives a request from an unauthorized local caller claiming a valid agent ID | Refuse signing regardless of self-declared identity or attacker-issued attestation |
| N5 | Replay enrollment authorization and nonce to establish another session | Reject; accepted enrollment has one recorded session context |
| N6 | Expired/revoked certificate, revoked identity key, or stale recovery generation with otherwise valid signatures | Reject enrollment; previously accepted sessions cannot outlive applicable revocation or lifecycle changes |
| N7 | Legitimate enrolled session signs several distinct permitted actions within its deadline | Accept without repeatedly using the identity private key; still enforce action replay and scope checks |
| N8 | Expanded scope or new session key is proposed under existing authorization | Require new enrollment and fresh identity-key signature |

## Emergency actions

| ID | Setup or change | Required result |
|---|---|---|
| E1 | Eligible certificate expiry, independently verified emergency holder, signed limited grant, fresh transaction proof, healthy status and ledger | Permit only the stated action; identity remains failed and authorization is restricted-emergency |
| E2 | Copy a valid grant but sign with another key | Reject; affected agent ID does not substitute for holder-key possession |
| E3 | Sign with a failed normal session key or an unverified replacement holder | Reject; independent emergency enrollment is required |
| E4 | Alter audience, request scope, incident, recovery generation, or grant content | Reject signature or context mismatch |
| E5 | Submit an expired, revoked, or wrong-authority grant | Reject before reserving or executing any effect |
| E6 | Known revocation or compromise exists alongside a permitted outage | Hard denial wins, including after restart or use of stale normal status |
| E7 | Missing identity, bad signature, replay, rejected attestation, or re-registration-required state | Reject emergency eligibility; do not relabel as an outage |
| E8 | Emergency authority/holder/incident status, reliable time, or shared usage ledger is unavailable | Deny; no local-counter fallback |
| E9 | Two receivers race to spend a grant with max_uses=1 | Exactly one reservation and at most one effect; gateway precheck does not consume an extra allowance |
| E10 | A response is lost after reservation or effect | Keep allowance spent; reconcile the same transaction before any retry; never blindly repeat an uncertain effect |
| E11 | Reuse transaction ID with different content, or replay its nonce | Reject changed content and replay; an exact retry cannot create another effect |
| E12 | Incident closes, recovery generation changes, or holder enrollment is revoked before nominal grant expiry | Existing grant no longer permits actions |
| E13 | Present an emergency envelope to the normal identity endpoint, or request delegation to another key | Reject profile confusion or delegation; do not report identity-valid |

## Evidence required from a future implementation

Record expected and actual decisions, reason codes, and effect counts. Include durable ledger state and lifecycle changes for concurrency/restart cases. Test the denial paths as well as the successful cases. Any failing scenario blocks claims that these properties have been demonstrated. Passing these tests alone does not address the review's separate intent, delegation, request-interpretation, or proof-fetching gaps.
