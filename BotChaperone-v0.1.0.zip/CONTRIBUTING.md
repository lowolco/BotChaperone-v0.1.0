# Contributing to BotChaperone

Thank you for helping stress-test this project.

BotChaperone is at an early research stage. Contributions that identify weaknesses are as valuable as contributions that add features.

## Ways to contribute

Useful contributions include:

- threat-model improvements;
- protocol design;
- privacy analysis;
- cryptographic review;
- standards mapping;
- architecture diagrams;
- case studies;
- implementation prototypes;
- red-team scenarios;
- governance analysis;
- documentation improvements;
- critiques showing why a proposed mechanism cannot work.

## Before proposing a new mechanism

Please answer:

1. What problem does it solve?
2. What is the trust boundary?
3. What prevents the agent from bypassing it?
4. What happens if the host is compromised?
5. What metadata does it expose?
6. How is it revoked?
7. Can an attacker proxy or launder the identity?
8. Which existing standard could solve the same problem?

## Design requirements

Proposals should prefer:

- least privilege;
- short-lived credentials;
- external enforcement;
- data minimization;
- interoperability;
- cryptographic agility;
- defense in depth;
- explicit failure modes.

Avoid designs that depend solely on:

- prompt instructions;
- voluntary self-identification by the model;
- one central global authority;
- permanent public identifiers;
- security through obscurity.

## Case studies

Case studies must distinguish:

- documented fact;
- source attribution;
- inference;
- counterfactual analysis;
- unresolved uncertainty.

Do not present a proposed control as having “prevented” a historical incident unless there is strong evidence supporting that conclusion.

## Pull requests

A pull request should include:

- a concise description;
- the problem being addressed;
- security implications;
- privacy implications;
- known limitations;
- references where applicable.

## Discussion style

Critique ideas, not people.

Strong disagreement is welcome when it is specific, evidence-based, and useful.

## Security vulnerabilities

Do not publish exploitable vulnerabilities affecting real systems in an issue.

See [SECURITY.md](SECURITY.md).
