# Architecture

## Overview

HumanSafe AI separates agent behavior from the infrastructure that authorizes and records that behavior.

```mermaid
flowchart LR
    A[AI Agent] --> B[Trusted Runtime]
    B --> C[Identity Attestation]
    C --> D[Capability Policy Engine]
    D --> E[Enforcement Gateway]
    E --> F[Signed Action Envelope]
    F --> G[External Service]
    G --> H[Verifier]
    H --> I[Local Policy]
    I --> J[Audit / Monitoring]
    J --> K[Revocation / Response]
```

## Components

### 1. AI Agent

The model or agentic application proposes actions.

The agent is **not** the root of trust.

### 2. Trusted Runtime

The runtime binds a specific executing process or agent session to an identity.

Possible implementations could include:

- hardened containers;
- virtual machines;
- confidential-computing environments;
- operating-system process identity;
- hardware-backed attestation;
- signed workload identity.

The exact implementation is an open research question.

### 3. Agent Identity Service

Issues short-lived, verifiable identity credentials.

An identity could bind:

- responsible organization;
- workload or agent instance;
- runtime;
- task or purpose;
- policy version;
- expiry;
- issuer;
- optional model-family metadata.

Sensitive metadata should not automatically be exposed to every destination.

### 4. Capability Policy Engine

Evaluates what the identified agent may do.

Example capabilities:

```yaml
capabilities:
  network:
    internet: false
    destinations:
      - "internal.example"
  credentials:
    use_external_tokens: false
  tools:
    shell: true
    browser: false
  data:
    read_classification:
      - "public"
      - "evaluation"
  agent_creation:
    allowed: false
```

The policy should follow least privilege and expire with the task.

### 5. Policy Enforcement Gateway

The gateway is the critical control point.

It should:

- reject unauthorized destinations;
- prevent untagged external traffic;
- attach signed provenance to authorized traffic;
- enforce rate and scope limits;
- generate security telemetry;
- support emergency revocation.

A major design challenge is preventing an agent from discovering an alternate egress path around the gateway.

### 6. Signed Action Envelope

An authorized external action may carry a cryptographically verifiable envelope.

A future standard might include:

```json
{
  "issuer": "org.example",
  "agent_instance": "urn:agent:8f21",
  "capability": "https.request",
  "destination_class": "approved-external",
  "policy_id": "policy-2026-09-v3",
  "issued_at": "2026-09-18T12:00:00Z",
  "expires_at": "2026-09-18T12:05:00Z",
  "nonce": "example",
  "signature": "..."
}
```

The production format should avoid unnecessary information leakage.

### 7. Receiving Verifier

A destination should be able to:

- verify the issuer;
- validate signature and freshness;
- check revocation;
- apply local policy;
- reject unsupported or prohibited agent classes.

The destination remains sovereign over its own authorization policy.

### 8. Audit and Provenance Layer

Relevant actions should generate tamper-resistant records sufficient for incident reconstruction.

The architecture should favor:

- minimal necessary metadata;
- strong integrity;
- controlled retention;
- privacy-preserving correlation;
- clear access controls.

### 9. Revocation Service

Revocation must work at several levels:

- individual agent instance;
- capability;
- workload;
- issuer credential;
- organization trust relationship.

Revocation should not require cooperation from the agent.

---

## Trust boundaries

```mermaid
flowchart TD
    subgraph U[Untrusted / Agent-Controlled]
        A[Model Output]
        B[Tool Requests]
    end

    subgraph T[Trusted Security Boundary]
        C[Runtime Identity]
        D[Policy Engine]
        E[Network Enforcement]
        F[Signing Service]
    end

    subgraph X[External Trust Domain]
        G[Destination Verifier]
        H[Destination Policy]
    end

    A --> C
    B --> D
    C --> D
    D --> E
    E --> F
    F --> G
    G --> H
```

The project's most important architectural claim is that **identity and authorization must cross a trust boundary the model cannot directly control**.

---

## Deployment models

Possible future deployment models include:

### Enterprise-only

An organization uses agent identity internally without any global standard.

### Federated

Organizations trust selected external issuers.

### Internet-scale

A common protocol enables broad verification across providers.

### High-risk-sector profile

Financial, healthcare, infrastructure, government, or cybersecurity systems define stricter capability profiles.

No deployment model is assumed to be universally appropriate.

---

## Relationship to existing technologies

A mature design should reuse existing standards where possible rather than inventing cryptography unnecessarily.

Areas to investigate include:

- workload identity;
- OAuth and delegated authorization;
- SPIFFE/SPIRE;
- mTLS;
- Web PKI;
- JWT/CWT-style signed claims;
- hardware-backed attestation;
- transparency logs;
- software supply-chain provenance;
- zero-trust architecture;
- policy engines;
- confidential computing.

The project's contribution may ultimately be a **profile and interoperability layer** connecting existing primitives specifically for autonomous agents.
