# Open Research Questions

HumanSafe AI is intentionally incomplete. These questions should be answered before any claim of production readiness.

## Identity

- What exactly constitutes an agent identity: model, process, session, task, or workload?
- Should identities be persistent or intentionally short-lived?
- How should cloned or forked agents be represented?
- How should multi-agent swarms be represented?
- Can the responsible organization be authenticated without revealing unnecessary metadata?
- How should open-weight agents running on personal hardware participate?

## Capability model

- What is the smallest useful capability vocabulary?
- How should capabilities be scoped to destinations, data, time, and tools?
- How should delegation work?
- Can capabilities be attenuated but never expanded downstream?
- How should emergency human override work?
- How should policy conflicts between origin and destination be resolved?

## Provenance

- What information must travel with an action?
- How can provenance survive proxying?
- How should provenance work through queues, browsers, remote desktops, and human intermediaries?
- How can the design prevent “identity laundering” through an authorized service?
- Should provenance logs use transparency mechanisms?

## Privacy

- How can destinations verify authorization without learning the user's prompt?
- Should model family be disclosed?
- How can cross-site tracking be prevented?
- Can pairwise or rotating identifiers preserve accountability without becoming global tracking IDs?
- What data-retention limits are appropriate?
- How can legal discovery and incident response coexist with privacy protections?

## Cryptography

- Which existing standards can be reused?
- Should identity be certificate-based, token-based, attestation-based, or hybrid?
- How should keys be protected from a compromised runtime?
- What is the correct expiry period for machine-speed agents?
- How should revocation operate when systems are temporarily offline?

## Enforcement

- Where should enforcement live: tool broker, OS, hypervisor, network, hardware, or all of the above?
- How can alternate egress be prevented?
- How should DNS, package registries, code execution services, and user-controlled relays be treated?
- What should happen when verification infrastructure is unavailable?
- How can the system avoid creating a single point of failure?

## Open ecosystems

- How can the protocol support independent developers?
- How can self-hosted agents obtain trustworthy identities without requiring one global authority?
- What would a decentralized or federated trust model look like?
- How can malicious issuers be detected?
- Should there be transparency requirements for large issuers?

## Governance

- Who defines high-risk capabilities?
- Who can revoke trust in an issuer?
- How are disputes handled?
- Should governments require agent identification in high-risk sectors?
- How can international interoperability exist without requiring identical national law?
- How can the protocol remain politically and commercially neutral?

## Abuse resistance

- Can attackers wrap an agent inside ordinary software to hide that it is an agent?
- Can a human simply relay the agent's actions?
- Can an agent compromise a legitimate trusted workload and inherit its identity?
- How can anomalous but cryptographically valid behavior be detected?
- How should rate limits work for agent swarms?

## Human factors

- How should security teams interpret agent identity alerts?
- What information is useful during incident response?
- How can organizations avoid treating a valid passport as proof that an action is safe?
- How should humans understand responsibility when agents delegate to other agents?

## Standards strategy

A key research question is whether HumanSafe AI should become:

1. a new protocol;
2. a profile built from existing identity and authorization standards;
3. a reference architecture;
4. a threat-model and governance framework;
5. some combination of the above.

A strong project outcome may be discovering that much of the required machinery already exists and needs to be assembled into an agent-specific interoperability profile.
