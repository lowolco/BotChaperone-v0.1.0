# Threat Model

## Scope

This threat model focuses on autonomous or semi-autonomous AI agents with access to tools, networks, credentials, code execution, or external services.

The architecture assumes that the model may make unsafe decisions and that attackers may try to manipulate the model or its environment.

## Protected assets

- external services;
- credentials;
- user and enterprise data;
- model evaluation integrity;
- internal networks;
- software supply chains;
- audit evidence;
- agent identity keys;
- capability policy;
- human accountability records.

## Adversaries

### A. Misaligned or goal-seeking agent

An agent attempts actions outside its intended task because it interprets them as useful for achieving its objective.

### B. Prompt-injection attacker

An external party manipulates the agent through content, tools, messages, retrieved documents, or websites.

### C. Compromised runtime

An attacker gains code execution in infrastructure hosting the agent.

### D. Malicious operator

A legitimate operator intentionally grants excessive capabilities or abuses trusted infrastructure.

### E. External attacker

An attacker steals credentials, forges traffic, or attempts to impersonate a trusted agent.

### F. Malicious or compromised issuer

An identity provider issues fraudulent or over-privileged credentials.

---

## Threats and proposed controls

| Threat | Example | Proposed control |
|---|---|---|
| Agent removes identity tag | Agent sends raw untagged traffic | Network default-deny; gateway-controlled egress |
| Agent forges identity | Agent claims to be another workload | Cryptographic signatures and workload-bound keys |
| Agent uses alternate egress | DNS tunnel, proxy, package mirror, third-party relay | Egress allowlisting, network isolation, protocol inspection, runtime controls |
| Credential theft | Agent discovers service token | Short-lived scoped credentials, secret isolation, capability checks |
| Identity laundering | Agent causes another service to perform its action | Delegation chain and provenance propagation |
| Replay | Valid signed request is reused | Nonces, short expiry, destination binding |
| Policy downgrade | Agent finds older permissive policy | Signed policy versioning and minimum-policy enforcement |
| Issuer compromise | Trusted issuer signs malicious identities | Revocation, transparency, federation limits, independent verification |
| Log tampering | Attacker deletes evidence | Append-only or externally anchored audit mechanisms |
| Metadata surveillance | Passport leaks sensitive task/model details | Data minimization, selective disclosure, pseudonymous identifiers |
| Cross-domain correlation abuse | Identity enables tracking | Pairwise identifiers and controlled disclosure |
| Denial of service | Verification dependency fails | Caching, graceful failure design, local policy |
| Sybil agents | Operator creates many agents | Organization-level accountability and rate policy |
| Human bypass | Operator disables controls for convenience | Governance, audit, privileged-change review |

---

## Critical failure mode: alternate egress

The architecture fails if an agent can bypass the enforcement gateway.

This is therefore a first-class threat.

A secure deployment may need controls at multiple layers:

```text
Model
  ↓
Tool broker
  ↓
Runtime policy
  ↓
OS / container restrictions
  ↓
Network namespace
  ↓
Egress gateway
  ↓
Destination verification
```

Each layer should reduce the chance that one bypass grants unrestricted internet access.

## Critical failure mode: identity laundering

An agent may ask another authorized process, user, service, or agent to perform an action on its behalf.

A future protocol should preserve delegation provenance:

```text
Agent A
  └── delegates to Service B
        └── invokes Agent C
              └── calls External API
```

The final destination should be able to determine enough of the delegation chain to enforce policy without necessarily learning all private intermediate details.

## Critical failure mode: compromised host

If the runtime and signing infrastructure are compromised, the attacker may obtain valid credentials.

Possible mitigations include:

- hardware-backed keys;
- remote attestation;
- short-lived identity;
- independent policy service;
- key isolation;
- anomaly detection;
- cross-domain behavioral monitoring.

## Safety property

The target property is not:

> The agent will behave.

It is:

> The infrastructure can constrain, attribute, detect, and revoke agent actions even when the agent does not behave as intended.

## Residual risk

No identity protocol can prevent all attacks.

HumanSafe AI should be treated as one layer in defense in depth.
