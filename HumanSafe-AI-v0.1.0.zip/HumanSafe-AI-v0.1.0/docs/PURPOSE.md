# Project Purpose

## Mission

HumanSafe AI explores an interoperable security layer for autonomous AI agents.

The project's purpose is to make consequential agent actions more:

- identifiable;
- explicitly authorized;
- traceable;
- auditable;
- revocable;
- accountable to a responsible human organization.

The project is motivated by a simple observation: existing internet identity systems were largely designed around people, services, applications, and devices. Autonomous agents increasingly act across all four categories.

## Problem statement

An AI agent may be able to:

- execute code;
- use tools;
- authenticate to services;
- send messages;
- interact with APIs;
- create other agents;
- move between services;
- use credentials;
- discover unintended communication paths.

If these actions appear as ordinary application traffic, defenders may have difficulty determining that an autonomous agent initiated them or determining which model instance was responsible.

A human-readable label is not enough. A malicious or misaligned process can remove it.

HumanSafe AI therefore explores **infrastructure-issued identity and authorization**.

## Security objective

The desired invariant is:

> No consequential external agent action should be accepted solely because the model chose to perform it.

Instead, trusted infrastructure should independently verify:

1. the identity of the executing agent instance;
2. the organization responsible for it;
3. the capability requested;
4. whether current policy authorizes that capability;
5. whether the authorization is still valid;
6. whether the destination accepts the issuing trust domain.

## Non-goals

HumanSafe AI is not intended to:

- guarantee that an AI system is aligned;
- determine whether an AI is conscious;
- replace existing cybersecurity controls;
- assign legal personhood to AI;
- expose private prompts or model reasoning;
- require public disclosure of every agent action;
- create a universal surveillance system;
- centralize control of all AI under one authority.

The project should be designed to minimize disclosure while still enabling meaningful authentication and accountability.

## Design philosophy

The protocol should assume that some agents may be:

- compromised;
- misaligned;
- adversarially prompted;
- poorly configured;
- over-privileged;
- operating inside a compromised host.

This leads to an important design rule:

> Trust the enforcement boundary, not the model's self-description.
